# Proposed Solution
An enhancement has been implemented to improve the handling of application package identifiers in cases where this information is not explicitly provided. The updated logic now ensures a reliable fallback mechanism: it first checks the application’s manifest file for the package name and, if not found, defaults to the file name. This improvement maintains consistency in application identification and ensures compatibility with version management and API-based access.

# Impacted Area
Testing is needed to perform a quick sanity check on the bundling functionality. The setup includes importing APKs using the "Import Package" operation in the Packages section and ensuring that bundling handles different versions consistently.

Patch 1-
1) Soti.MobiControl.WebApi.dll

# Area to be tested
Testing is needed to validate scenarios where Android applications are imported using the "Import Package" operation without relying solely on manifest-defined package names. The setup includes verifying bundling behavior across multiple application versions and ensuring consistent handling via the public API. 

# How to apply the patch 
1) Launch MCAU and Stop MS and DS Services and wait for services to stop. 
2) Take the backup of the dll's mentioned above from the installation directory of MobiControl
3) Replace all above mentioned dll files
4) Start Services from MCAU and wait, verify scope once services are up and running. 
5) Perform all steps on all servers.