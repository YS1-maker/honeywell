# Proposed Solution
An enhancement has been implemented to improve the handling of application package identifiers in cases where this information is not explicitly provided. The updated logic now ensures a reliable fallback mechanism: it first checks the application’s manifest file for the package name and, if not found, defaults to the file name. This improvement maintains consistency in application identification and ensures compatibility with version management and API-based access.

# Impacted Area
Testing is needed to perform a quick sanity check on the bundling functionality. The setup includes importing APKs using the "Import Package" operation in the Packages section and ensuring that bundling handles different versions consistently.

# Area to be tested
Testing is needed to validate scenarios where Android applications are imported using the "Import Package" operation without relying solely on manifest-defined package names. The setup includes verifying bundling behavior across multiple application versions and ensuring consistent handling via the public API. 

# Summary
This document describes the step-by-step procedure to apply the patch to an installed MobiControl Insatnce. It updates DLLs and requires a small edit to the host configuration (`Soti.MobiControl.ManagementService.Host.exe.config`) to include binding redirects / assembly entries for the updated MacroResolution packages.

Files included in this patch-
1) `Soti.MobiControl.Core.Implementation.dll`
2) `Soti.MobiControl.MacroResolution.dll`
3) `Soti.MobiControl.MacroResolution.Implementation.dll`
4) `Soti.MobiControl.WebApi.dll`
5) `Soti.MobiControl.WebApi.xml`

## Step-by-step installation

> All paths used below are examples — adjust paths and directory names to your environment.

1) Stop services (recommended: use MCAU)
    - Launch MCAU (MobiControl Admin Utility) and Stop the MobiControl Deployment Server and MobiControl Management Services. Wait until both services report as stopped.
2) Backup files to restore if needed
    - Backup only the files to be replaced (recommended)
3) Replace DLLs
    - Copy the patched DLLs from patch's assemblies directory into the install folder (C:\Program Files\SOTI\ManagementService).
4) Update host config (`C:\Program Files\SOTI\ManagementService\Soti.MobiControl.ManagementService.Host.exe.config`)
    - Keep a copy of the original `Soti.MobiControl.ManagementService.Host.exe.config` in the backup folder (step 2) so you can revert quickly
    - Open `Soti.MobiControl.ManagementService.Host.exe.config` in a text editor with admin rights.
    - Insert the provided snippet before the closing </runtime> tag.
        Example: full runtime section in Soti.MobiControl.ManagementService.Host.exe.config:
        <runtime>
            <assemblyBinding xmlns="urn:schemas-microsoft-com:asm.v1">
                <!-- Existing dependentAssembly entries -->
            </assemblyBinding>
        
            <!-- INSERT PATCH CODE SNIPPET HERE -->

        </runtime>

        PATCH CODE SNIPPET START: 
            <assemblyBinding xmlns="urn:schemas-microsoft-com:asm.v1">
                <dependentAssembly>
                    <assemblyIdentity name="Soti.MobiControl.MacroResolution.Implementation" publicKeyToken="a29bacbc13661f13" culture="neutral" />
                    <bindingRedirect oldVersion="0.0.0.0-2.7.0.0" newVersion="2.7.0.0" />
                </dependentAssembly>
            </assemblyBinding>
            <assemblyBinding xmlns="urn:schemas-microsoft-com:asm.v1">
                <dependentAssembly>
                    <assemblyIdentity name="Soti.MobiControl.MacroResolution" publicKeyToken="a29bacbc13661f13" culture="neutral" />
                    <bindingRedirect oldVersion="0.0.0.0-1.7.0.0" newVersion="1.7.0.0" />
                </dependentAssembly>
            </assemblyBinding>
        PATCH CODE SNIPPET END:
    - Save the file
5) Start services
    - Start services from MCAU and wait until they’re fully Running.
6) Perform all steps on all servers.


## Rollback (if something goes wrong)

1) Stop services (same as Step 1).
2) Restore DLLs from backup folder created earlier (Step 2)
3) Restore original host config.
4) Start services and validate.

